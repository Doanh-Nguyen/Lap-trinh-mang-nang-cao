
import com.ltmnc.client.CryptoClient;
import com.ltmnc.common.CryptoUtils;
import com.ltmnc.common.Message;
import org.junit.Test;

import javax.crypto.SecretKey;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;

import static org.junit.Assert.*;

public class ClientTest {

    @Test
    public void testCryptoUtilsAESEncryption() throws Exception {
        // Test AES encryption/decryption
        String originalText = "Hello LTMNC!";
        SecretKey aesKey = CryptoUtils.generateAESKey();
        byte[] iv = CryptoUtils.generateIV();

        String encrypted = CryptoUtils.encryptAES(originalText, aesKey, iv);
        String decrypted = CryptoUtils.decryptAES(encrypted, aesKey, iv);

        assertEquals("AES encryption/decryption should work correctly", originalText, decrypted);
        assertNotEquals("Encrypted text should be different from original", originalText, encrypted);
    }

    @Test
    public void testCryptoUtilsRSASignature() throws Exception {
        // Test RSA signature
        String message = "Test message for signature";

        // Generate test key pair
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair keyPair = keyGen.generateKeyPair();

        PrivateKey privateKey = keyPair.getPrivate();
        PublicKey publicKey = keyPair.getPublic();

        // Sign and verify
        String signature = CryptoUtils.signWithRSA(message, privateKey);
        boolean isValid = CryptoUtils.verifyWithRSA(message, signature, publicKey);

        assertTrue("Signature should be valid", isValid);

        // Test with wrong message
        boolean isInvalid = CryptoUtils.verifyWithRSA("Wrong message", signature, publicKey);
        assertFalse("Signature should be invalid for wrong message", isInvalid);
    }

    @Test
    public void testCryptoUtilsRSAEncryption() throws Exception {
        // Test RSA encryption/decryption
        String originalData = "Test data for RSA";

        // Generate test key pair
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair keyPair = keyGen.generateKeyPair();

        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        // Encrypt and decrypt
        String encrypted = CryptoUtils.encryptRSA(originalData.getBytes(), publicKey);
        byte[] decrypted = CryptoUtils.decryptRSA(encrypted, privateKey);
        String decryptedText = new String(decrypted);

        assertEquals("RSA encryption/decryption should work correctly", originalData, decryptedText);
    }

    @Test
    public void testSHA256Hash() throws Exception {
        String message = "Test message for hashing";
        byte[] hash1 = CryptoUtils.sha256Hash(message);
        byte[] hash2 = CryptoUtils.sha256Hash(message);

        assertArrayEquals("Same message should produce same hash", hash1, hash2);
        assertEquals("SHA256 hash should be 32 bytes", 32, hash1.length);

        // Different message should produce different hash
        byte[] differentHash = CryptoUtils.sha256Hash("Different message");
        assertFalse("Different messages should produce different hashes",
                java.util.Arrays.equals(hash1, differentHash));
    }

    @Test
    public void testMessageSerialization() throws Exception {
        Message message = new Message("Test message");
        message.setSignature("test_signature");
        message.setEncryptedMessage("encrypted_content");
        message.setIv("test_iv");

        // Test getters
        assertEquals("Test message", message.getRawMessage());
        assertEquals("test_signature", message.getSignature());
        assertEquals("encrypted_content", message.getEncryptedMessage());
        assertEquals("test_iv", message.getIv());

        // Test toString
        String messageStr = message.toString();
        assertTrue("toString should contain raw message", messageStr.contains("Test message"));
        assertTrue("toString should contain signature", messageStr.contains("test_signature"));
    }
}



import com.ltmnc.server.DatabaseManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.SQLException;

import static org.junit.Assert.*;

public class ServerTest {

    private DatabaseManager databaseManager;

    @Before
    public void setUp() throws Exception {
        databaseManager = new DatabaseManager();
        databaseManager.initializeDatabase();
    }

    @After
    public void tearDown() throws Exception {
        if (databaseManager != null) {
            databaseManager.close();
        }
    }

    @Test
    public void testDatabaseInitialization() throws Exception {
        // Database should be initialized without errors
        assertNotNull("DatabaseManager should not be null", databaseManager);

        // Should be able to get session count
        int count = databaseManager.getSessionCount();
        assertTrue("Session count should be non-negative", count >= 0);
    }

    @Test
    public void testStoreAndRetrieveKeys() throws Exception {
        // Test data
        String testAESKey = "test_encrypted_aes_key_12345";
        String testIV = "test_iv_123456";
        String testPublicKey = "-----BEGIN PUBLIC KEY-----\ntest_public_key_content\n-----END PUBLIC KEY-----";

        // Store keys
        databaseManager.storeKeys(testAESKey, testIV, testPublicKey);

        // Retrieve latest session
        DatabaseManager.SessionInfo session = databaseManager.getLatestSession();

        assertNotNull("Latest session should not be null", session);
        assertEquals("Stored AES key should match", testAESKey, session.encryptedAESKey);
        assertEquals("Stored IV should match", testIV, session.iv);
        assertEquals("Stored public key should match", testPublicKey, session.clientPublicKey);
        assertNotNull("Session ID should not be null", session.sessionId);
        assertNotNull("Created at should not be null", session.createdAt);
    }

    @Test
    public void testMultipleSessionsStorage() throws Exception {
        int initialCount = databaseManager.getSessionCount();

        // Store multiple sessions
        for (int i = 0; i < 3; i++) {
            databaseManager.storeKeys(
                    "aes_key_" + i,
                    "iv_" + i,
                    "public_key_" + i
            );
        }

        int finalCount = databaseManager.getSessionCount();
        assertEquals("Should have 3 more sessions", initialCount + 3, finalCount);

        // Latest session should be the last one stored
        DatabaseManager.SessionInfo latestSession = databaseManager.getLatestSession();
        assertEquals("Latest session should have correct AES key", "aes_key_2", latestSession.encryptedAESKey);
        assertEquals("Latest session should have correct IV", "iv_2", latestSession.iv);
    }

    @Test
    public void testSessionCleaning() throws Exception {
        // Store multiple sessions
        for (int i = 0; i < 5; i++) {
            databaseManager.storeKeys(
                    "cleanup_aes_key_" + i,
                    "cleanup_iv_" + i,
                    "cleanup_public_key_" + i
            );
        }

        int countBeforeCleanup = databaseManager.getSessionCount();
        assertTrue("Should have at least 5 sessions", countBeforeCleanup >= 5);

        // Clean old sessions, keep only 3
        databaseManager.cleanOldSessions(3);

        int countAfterCleanup = databaseManager.getSessionCount();
        assertTrue("Should have at most 3 sessions after cleanup", countAfterCleanup <= 3);
    }

    @Test
    public void testSessionInfoToString() {
        DatabaseManager.SessionInfo sessionInfo = new DatabaseManager.SessionInfo();
        sessionInfo.id = 123;
        sessionInfo.sessionId = "TEST_SESSION";
        sessionInfo.createdAt = new java.sql.Timestamp(System.currentTimeMillis());

        String sessionStr = sessionInfo.toString();
        assertTrue("toString should contain ID", sessionStr.contains("123"));
        assertTrue("toString should contain session ID", sessionStr.contains("TEST_SESSION"));
    }

    @Test
    public void testSubdomainScannerWordlistLoading() {
        // Note: This test would require network access to test the actual wordlist loading
        // For unit testing, we can test the basic functionality

        assertTrue("Basic test should pass", true);

        // In a real scenario, you might want to:
        // 1. Mock the HTTP connection
        // 2. Test with a local test wordlist
        // 3. Test the subdomain validation logic separately
    }
}
package com.ltmnc.client;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltmnc.common.Message;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.util.CharsetUtil;

public class NettyClient {
    private final String host;
    private final int port;
    private EventLoopGroup group;
    private Channel channel;
    private CryptoClient cryptoClient;
    private ObjectMapper objectMapper;

    public NettyClient(String host, int port) {
        this.host = host;
        this.port = port;
        this.cryptoClient = new CryptoClient();
        this.objectMapper = new ObjectMapper();
    }

    public void connect() throws InterruptedException {
        group = new NioEventLoopGroup();

        try {
            Bootstrap bootstrap = new Bootstrap();
            bootstrap.group(group)
                    .channel(NioSocketChannel.class)
                    .handler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) throws Exception {
                            ChannelPipeline pipeline = ch.pipeline();
                            pipeline.addLast(new StringDecoder(CharsetUtil.UTF_8));
                            pipeline.addLast(new StringEncoder(CharsetUtil.UTF_8));
                            pipeline.addLast(new ClientHandler());
                        }
                    });

            // Kết nối đến server
            ChannelFuture future = bootstrap.connect(host, port).sync();
            channel = future.channel();

            System.out.println("Đã kết nối đến server: " + host + ":" + port);

        } catch (Exception e) {
            System.err.println("Lỗi khi kết nối đến server: " + e.getMessage());
            group.shutdownGracefully();
            throw e;
        }
    }

    public void sendMessage(String rawMessage) {
        try {
            // Tạo và mã hóa message
            Message message = cryptoClient.createEncryptedMessage(rawMessage);

            // Convert message thành JSON string
            String jsonMessage = objectMapper.writeValueAsString(message);

            // Gửi message qua channel
            if (channel != null && channel.isActive()) {
                channel.writeAndFlush(jsonMessage + "\n");
                System.out.println("Đã gửi message được mã hóa đến server");
            } else {
                System.err.println("Channel không active, không thể gửi message");
            }

        } catch (Exception e) {
            System.err.println("Lỗi khi gửi message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void disconnect() {
        try {
            if (channel != null) {
                channel.close().sync();
            }
        } catch (InterruptedException e) {
            System.err.println("Lỗi khi đóng channel: " + e.getMessage());
        } finally {
            if (group != null) {
                group.shutdownGracefully();
            }
        }
        System.out.println("Đã ngắt kết nối khỏi server");
    }
}

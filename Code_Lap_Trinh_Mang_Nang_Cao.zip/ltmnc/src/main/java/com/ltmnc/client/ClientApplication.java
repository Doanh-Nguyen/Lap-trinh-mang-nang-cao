package com.ltmnc.client;


import java.util.Scanner;

public class ClientApplication {

    public static void main(String[] args) {
        System.out.println("=== LTMNC Client Application ===");

        try {
            // Khởi tạo client
            NettyClient client = new NettyClient("localhost", 8080);

            // Kết nối đến server
            client.connect();

            // Scanner để nhập message từ console
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.print("\nNhập message để gửi (hoặc 'quit' để thoát): ");
                String input = scanner.nextLine().trim();

                if ("quit".equalsIgnoreCase(input)) {
                    System.out.println("Đang thoát client...");
                    break;
                }

                if (input.isEmpty()) {
                    System.out.println("Message không được rỗng!");
                    continue;
                }

                // Gửi message đến server
                System.out.println("Đang gửi message: " + input);
                client.sendMessage(input);

                // Chờ một chút để nhận response
                Thread.sleep(2000);
            }

            // Đóng kết nối
            client.disconnect();
            scanner.close();

        } catch (Exception e) {
            System.err.println("Lỗi trong client application: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("Client đã thoát.");
    }
}

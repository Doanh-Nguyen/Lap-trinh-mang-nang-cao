package com.ltmnc.client;

import com.ltmnc.common.CryptoUtils;
import com.ltmnc.common.Message;

import javax.crypto.SecretKey;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

public class CryptoClient {

    private PrivateKey clientPrivateKey;
    private PublicKey clientPublicKey;
    private PublicKey serverPublicKey;

    public CryptoClient() {
        try {
            // Load client keys
            this.clientPrivateKey = CryptoUtils.loadPrivateKey("keys/client-private.pem");
            this.clientPublicKey = CryptoUtils.loadPublicKey("keys/client-public.pem");

            // Load server public key
            this.serverPublicKey = CryptoUtils.loadPublicKey("keys/server-public.pem");

            System.out.println("Đã load thành công các crypto keys");

        } catch (Exception e) {
            System.err.println("Lỗi khi load crypto keys: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public Message createEncryptedMessage(String rawMessage) throws Exception {
        Message message = new Message();
        message.setRawMessage(rawMessage);

        System.out.println("\n=== Bắt đầu quá trình mã hóa ===");

        // Bước 1: Tạo chữ ký số SHA256withRSA
        System.out.println("1. Tạo chữ ký số với SHA256withRSA...");
        String signature = CryptoUtils.signWithRSA(rawMessage, clientPrivateKey);
        message.setSignature(signature);
        System.out.println("   ✓ Chữ ký đã được tạo: " + signature.substring(0, 50) + "...");

        // Bước 2: Generate AES key và IV
        System.out.println("2. Tạo AES key và IV...");
        SecretKey aesKey = CryptoUtils.generateAESKey();
        byte[] iv = CryptoUtils.generateIV();
        System.out.println("   ✓ AES key và IV đã được tạo");

        // Bước 3: Mã hóa message bằng AES-CBC
        System.out.println("3. Mã hóa message bằng AES-CBC...");
        String encryptedMessage = CryptoUtils.encryptAES(rawMessage, aesKey, iv);
        message.setEncryptedMessage(encryptedMessage);
        System.out.println("   ✓ Chữ ký đã được tạo: " +
                (signature.length() > 50 ? signature.substring(0, 50) + "..." : signature));

        // Bước 4: Mã hóa AES key bằng RSA public key của server
        System.out.println("4. Mã hóa AES key bằng RSA...");
        byte[] aesKeyBytes = CryptoUtils.secretKeyToBytes(aesKey);
        String encryptedAESKey = CryptoUtils.encryptRSA(aesKeyBytes, serverPublicKey);
        message.setEncryptedAESKey(encryptedAESKey);
        System.out.println("   ✓ AES key đã được mã hóa: " + encryptedAESKey.substring(0, 50) + "...");

        // Bước 5: Encode IV và Public Key
        System.out.println("5. Encode IV và Public Key...");
        String ivBase64 = Base64.getEncoder().encodeToString(iv);
        message.setIv(ivBase64);

        String publicKeyStr = CryptoUtils.publicKeyToString(clientPublicKey);
        message.setPublicKey(publicKeyStr);
        System.out.println("   ✓ IV và Public Key đã được encode");

        System.out.println("=== Hoàn thành quá trình mã hóa ===\n");

        return message;
    }
}
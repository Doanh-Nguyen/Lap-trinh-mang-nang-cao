package com.ltmnc.client;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltmnc.common.Message;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

public class ClientHandler extends ChannelInboundHandlerAdapter {

    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("Kết nối đến server thành công!");
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        try {
            String jsonResponse = msg.toString().trim();
            System.out.println("\n=== Response từ Server ===");

            // Parse JSON response
            Message response = objectMapper.readValue(jsonResponse, Message.class);

            // Hiển thị response
            if (response.getResponse() != null) {
                System.out.println("Response: " + response.getResponse());
            }

            // Hiển thị scan results nếu có
            if (response.getScanResults() != null && !response.getScanResults().isEmpty()) {
                System.out.println("\n=== Kết quả Scan Subdomain ===");
                String[] subdomains = response.getScanResults().split("\n");
                System.out.println("Tìm thấy " + subdomains.length + " subdomain:");

                int count = 0;
                for (String subdomain : subdomains) {
                    if (!subdomain.trim().isEmpty()) {
                        System.out.println("  " + (++count) + ". " + subdomain.trim());

                        // Hiển thị tối đa 20 subdomain để tránh spam console
                        if (count >= 20) {
                            System.out.println("  ... và " + (subdomains.length - count) + " subdomain khác");
                            break;
                        }
                    }
                }
            }

            System.out.println("========================");

        } catch (Exception e) {
            System.err.println("Lỗi khi xử lý response từ server: " + e.getMessage());
            System.out.println("Raw response: " + msg.toString());
        }
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("Kết nối đến server đã bị ngắt");
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        System.err.println("Lỗi trong ClientHandler: " + cause.getMessage());
        cause.printStackTrace();
        ctx.close();
    }
}
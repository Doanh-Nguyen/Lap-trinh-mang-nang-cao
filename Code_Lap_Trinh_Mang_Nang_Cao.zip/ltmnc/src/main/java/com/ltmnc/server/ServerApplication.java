package com.ltmnc.server;


public class ServerApplication {

    public static void main(String[] args) {
        System.out.println("=== LTMNC Server Application ===");

        try {
            // Khởi tạo database
            DatabaseManager dbManager = new DatabaseManager();
            dbManager.initializeDatabase();
            System.out.println("Database đã được khởi tạo thành công");

            // Khởi tạo server
            NettyServer server = new NettyServer(8080);

            // Start server
            System.out.println("Đang khởi động server trên port 8080...");
            server.start();

            // Thêm shutdown hook để đóng server khi thoát
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                System.out.println("\nĐang thoát server...");
                server.stop();
                try {
                    dbManager.close();
                } catch (Exception e) {
                    System.err.println("Lỗi khi đóng database: " + e.getMessage());
                }
                System.out.println("Server đã thoát.");
            }));

            // Giữ cho server chạy
            System.out.println("Server đã sẵn sàng nhận kết nối từ client");
            System.out.println("Nhấn Ctrl+C để thoát server");

            // Chờ server chạy
            server.waitForShutdown();

        } catch (Exception e) {
            System.err.println("Lỗi trong server application: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

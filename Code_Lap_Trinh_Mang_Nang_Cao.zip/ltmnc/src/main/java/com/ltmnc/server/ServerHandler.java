package com.ltmnc.server;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ltmnc.common.Message;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

public class ServerHandler extends ChannelInboundHandlerAdapter {

    private ObjectMapper objectMapper = new ObjectMapper();
    private CryptoServer cryptoServer = new CryptoServer();
    private DatabaseManager databaseManager = new DatabaseManager();
    private SubdomainScanner subdomainScanner = new SubdomainScanner();

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("Client đã kết nối: " + ctx.channel().remoteAddress());
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        try {
            String jsonMessage = msg.toString().trim();
            System.out.println("\n=== Nhận request từ Client ===");
            System.out.println("Client: " + ctx.channel().remoteAddress());

            // Parse JSON message
            Message request = objectMapper.readValue(jsonMessage, Message.class);

            // Xử lý request
            Message response = processRequest(request);

            // Gửi response về client
            String jsonResponse = objectMapper.writeValueAsString(response);
            ctx.writeAndFlush(jsonResponse + "\n");

            System.out.println("Đã gửi response về client");
            System.out.println("================================\n");

        } catch (Exception e) {
            System.err.println("Lỗi khi xử lý request: " + e.getMessage());
            e.printStackTrace();

            // Gửi error response
            Message errorResponse = new Message();
            errorResponse.setResponse("SERVER_ERROR");
            String jsonResponse = objectMapper.writeValueAsString(errorResponse);
            ctx.writeAndFlush(jsonResponse + "\n");
        }
    }

    private Message processRequest(Message request) {
        Message response = new Message();

        try {
            System.out.println("1. Bắt đầu giải mã và verify...");

            // Bước 1: Lưu AES key/IV vào database
            databaseManager.storeKeys(request.getEncryptedAESKey(), request.getIv(),
                    request.getPublicKey());
            System.out.println("   ✓ Đã lưu keys vào database");

            // Bước 2: Giải mã message
            String decryptedMessage = cryptoServer.decryptMessage(request);
            System.out.println("   ✓ Đã giải mã message: " + decryptedMessage);

            // Bước 3: Verify signature
            boolean isValid = cryptoServer.verifySignature(decryptedMessage,
                    request.getSignature(),
                    request.getPublicKey());

            if (isValid) {
                System.out.println("   ✓ Signature verification THÀNH CÔNG");

                // Bước 4: Trả về "VERIFY"
                response.setResponse("VERIFY");
                System.out.println("2. Đã trả về VERIFY");

                // Bước 5: Scan subdomain
                System.out.println("3. Bắt đầu scan subdomain huflit.edu.vn...");
                String scanResults = subdomainScanner.scanSubdomains("huflit.edu.vn");
                response.setScanResults(scanResults);
                System.out.println("   ✓ Hoàn thành scan subdomain");

            } else {
                System.out.println("   ✗ Signature verification THẤT BẠI");
                response.setResponse("VERIFICATION_FAILED");
            }

        } catch (Exception e) {
            System.err.println("Lỗi khi xử lý request: " + e.getMessage());
            response.setResponse("VERIFICATION_FAILED");
        }

        return response;
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("Client đã ngắt kết nối: " + ctx.channel().remoteAddress());
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        System.err.println("Lỗi trong ServerHandler: " + cause.getMessage());
        cause.printStackTrace();
        ctx.close();
    }
}

package com.ltmnc.server;

import java.sql.*;
import java.time.LocalDateTime;

public class DatabaseManager {

    // MySQL connection configuration
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ltmnc_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "ltmnc_user01";
    private static final String DB_PASSWORD = "abc@123";

    private Connection connection;

    public DatabaseManager() {
        try {
            // Load MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Tạo kết nối
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            System.out.println("Kết nối MySQL thành công!");

        } catch (Exception e) {
            System.err.println("Lỗi khi tạo kết nối database: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void initializeDatabase() throws SQLException {
        System.out.println("Đang khởi tạo database schema...");

        String createTableSQL = "CREATE TABLE IF NOT EXISTS session_keys (" +
                "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                "encrypted_aes_key TEXT NOT NULL, " +
                "iv VARCHAR(255) NOT NULL, " +
                "client_public_key TEXT NOT NULL, " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "session_id VARCHAR(255) DEFAULT NULL" +
                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

        try (Statement statement = connection.createStatement()) {
            // Tạo table
            statement.execute(createTableSQL);
            System.out.println("Table session_keys đã được tạo");

            // Tạo indexes - MySQL không hỗ trợ IF NOT EXISTS cho index
            createIndexIfNotExists(statement, "idx_session_keys_created_at", "session_keys", "created_at");
            createIndexIfNotExists(statement, "idx_session_keys_session_id", "session_keys", "session_id");

            System.out.println("Database schema đã được tạo thành công");
        }
    }

    private void createIndexIfNotExists(Statement statement, String indexName, String tableName, String columnName) {
        try {
            String createIndexSQL = "CREATE INDEX " + indexName + " ON " + tableName + "(" + columnName + ")";
            statement.execute(createIndexSQL);
            System.out.println("Index " + indexName + " đã được tạo");
        } catch (SQLException e) {
            if (e.getMessage().contains("Duplicate key name") || e.getMessage().contains("already exists")) {
                System.out.println("Index " + indexName + " đã tồn tại, bỏ qua");
            } else {
                System.err.println("Lỗi khi tạo index " + indexName + ": " + e.getMessage());
            }
        }
    }

    public void storeKeys(String encryptedAESKey, String iv, String clientPublicKey) throws SQLException {
        String insertSQL = "INSERT INTO session_keys (encrypted_aes_key, iv, client_public_key, session_id) " +
                "VALUES (?, ?, ?, ?)";

        // Tạo session ID đơn giản
        String sessionId = "SESSION_" + System.currentTimeMillis();

        try (PreparedStatement statement = connection.prepareStatement(insertSQL)) {
            statement.setString(1, encryptedAESKey);
            statement.setString(2, iv);
            statement.setString(3, clientPublicKey);
            statement.setString(4, sessionId);

            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("   ✓ Đã lưu keys vào database với session ID: " + sessionId);
            } else {
                System.err.println("   ✗ Không thể lưu keys vào database");
            }
        }
    }

    public SessionInfo getLatestSession() throws SQLException {
        String selectSQL = "SELECT id, encrypted_aes_key, iv, client_public_key, created_at, session_id " +
                "FROM session_keys " +
                "ORDER BY created_at DESC " +
                "LIMIT 1";

        try (PreparedStatement statement = connection.prepareStatement(selectSQL);
             ResultSet resultSet = statement.executeQuery()) {

            if (resultSet.next()) {
                SessionInfo sessionInfo = new SessionInfo();
                sessionInfo.id = resultSet.getLong("id");
                sessionInfo.encryptedAESKey = resultSet.getString("encrypted_aes_key");
                sessionInfo.iv = resultSet.getString("iv");
                sessionInfo.clientPublicKey = resultSet.getString("client_public_key");
                sessionInfo.createdAt = resultSet.getTimestamp("created_at");
                sessionInfo.sessionId = resultSet.getString("session_id");

                return sessionInfo;
            }
        }

        return null;
    }

    public int getSessionCount() throws SQLException {
        String countSQL = "SELECT COUNT(*) as count FROM session_keys";

        try (PreparedStatement statement = connection.prepareStatement(countSQL);
             ResultSet resultSet = statement.executeQuery()) {

            if (resultSet.next()) {
                return resultSet.getInt("count");
            }
        }

        return 0;
    }

    public void cleanOldSessions(int maxSessions) throws SQLException {
        if (getSessionCount() > maxSessions) {
            // MySQL có cú pháp khác một chút cho DELETE với subquery
            String deleteSQL = "DELETE FROM session_keys " +
                    "WHERE id NOT IN (" +
                    "    SELECT * FROM (" +
                    "        SELECT id FROM session_keys " +
                    "        ORDER BY created_at DESC " +
                    "        LIMIT ?" +
                    "    ) AS temp_table" +
                    ")";

            try (PreparedStatement statement = connection.prepareStatement(deleteSQL)) {
                statement.setInt(1, maxSessions);
                int deletedRows = statement.executeUpdate();

                if (deletedRows > 0) {
                    System.out.println("Đã xóa " + deletedRows + " session cũ khỏi database");
                }
            }
        }
    }

    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
            System.out.println("Database connection đã được đóng");
        }
    }

    // Inner class để lưu thông tin session
    public static class SessionInfo {
        public long id;
        public String encryptedAESKey;
        public String iv;
        public String clientPublicKey;
        public Timestamp createdAt;
        public String sessionId;

        @Override
        public String toString() {
            return "SessionInfo{" +
                    "id=" + id +
                    ", sessionId='" + sessionId + '\'' +
                    ", createdAt=" + createdAt +
                    '}';
        }
    }
}
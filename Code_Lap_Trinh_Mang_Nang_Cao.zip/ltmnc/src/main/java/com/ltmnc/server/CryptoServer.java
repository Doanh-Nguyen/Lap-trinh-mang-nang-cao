package com.ltmnc.server;


import com.ltmnc.common.CryptoUtils;
import com.ltmnc.common.Message;

import javax.crypto.SecretKey;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

public class CryptoServer {

    private PrivateKey serverPrivateKey;
    private PublicKey serverPublicKey;

    public CryptoServer() {
        try {
            // Load server keys
            this.serverPrivateKey = CryptoUtils.loadPrivateKey("keys/server-private.pem");
            this.serverPublicKey = CryptoUtils.loadPublicKey("keys/server-public.pem");

            System.out.println("Server crypto keys đã được load thành công");

        } catch (Exception e) {
            System.err.println("Lỗi khi load server crypto keys: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public String decryptMessage(Message request) throws Exception {
        System.out.println("   - Bắt đầu giải mã message...");

        // Bước 1: Giải mã AES key bằng server private key
        byte[] aesKeyBytes = CryptoUtils.decryptRSA(request.getEncryptedAESKey(), serverPrivateKey);
        SecretKey aesKey = CryptoUtils.bytesToSecretKey(aesKeyBytes);
        System.out.println("     ✓ Đã giải mã AES key");

        // Bước 2: Decode IV
        byte[] iv = Base64.getDecoder().decode(request.getIv());
        System.out.println("     ✓ Đã decode IV");

        // Bước 3: Giải mã message bằng AES-CBC
        String decryptedMessage = CryptoUtils.decryptAES(request.getEncryptedMessage(), aesKey, iv);
        System.out.println("     ✓ Đã giải mã message bằng AES-CBC");

        return decryptedMessage;
    }

    public boolean verifySignature(String originalMessage, String signature, String clientPublicKeyStr) throws Exception {
        System.out.println("   - Bắt đầu verify signature...");

        // Load client public key từ string
        PublicKey clientPublicKey = CryptoUtils.loadPublicKeyFromString(clientPublicKeyStr);
        System.out.println("     ✓ Đã load client public key");

        // Verify signature với SHA256withRSA
        boolean isValid = CryptoUtils.verifyWithRSA(originalMessage, signature, clientPublicKey);

        if (isValid) {
            System.out.println("     ✓ Signature verification thành công");
        } else {
            System.out.println("     ✗ Signature verification thất bại");
        }

        return isValid;
    }

    // Getter methods cho các keys (nếu cần)
    public PrivateKey getServerPrivateKey() {
        return serverPrivateKey;
    }

    public PublicKey getServerPublicKey() {
        return serverPublicKey;
    }
}
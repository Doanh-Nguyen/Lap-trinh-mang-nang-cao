package com.ltmnc.server;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class SubdomainScanner {

    private static final String WORDLIST_URL = "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Discovery/DNS/subdomains-top1million-110000.txt";
    private static final int MAX_THREADS = 50;
    private static final int TIMEOUT_MS = 3000;
    private static final int MAX_SUBDOMAINS_TO_TEST = 1000; // Giới hạn để tránh quá lâu

    public String scanSubdomains(String domain) {
        List<String> foundSubdomains = new ArrayList<>();

        try {
            System.out.println("   - Đang tải wordlist từ SecLists...");
            List<String> wordlist = loadWordlist();
            System.out.println("   - Đã tải " + wordlist.size() + " từ từ wordlist");

            // Giới hạn số lượng subdomain để test
            int maxToTest = Math.min(wordlist.size(), MAX_SUBDOMAINS_TO_TEST);
            System.out.println("   - Sẽ test " + maxToTest + " subdomain đầu tiên");

            // Sử dụng ThreadPoolExecutor để scan parallel
            ExecutorService executor = Executors.newFixedThreadPool(MAX_THREADS);
            List<Future<String>> futures = new ArrayList<>();

            for (int i = 0; i < maxToTest; i++) {
                String subdomain = wordlist.get(i).trim() + "." + domain;

                Future<String> future = executor.submit(() -> {
                    if (isSubdomainValid(subdomain)) {
                        return subdomain;
                    }
                    return null;
                });

                futures.add(future);
            }

            // Collect results
            System.out.println("   - Đang scan các subdomain...");
            int completed = 0;
            for (Future<String> future : futures) {
                try {
                    String result = future.get(TIMEOUT_MS, TimeUnit.MILLISECONDS);
                    if (result != null) {
                        foundSubdomains.add(result);
                        System.out.println("     ✓ Tìm thấy: " + result);
                    }

                    completed++;
                    if (completed % 100 == 0) {
                        System.out.println("   - Đã hoàn thành: " + completed + "/" + maxToTest);
                    }

                } catch (TimeoutException e) {
                    future.cancel(true);
                } catch (Exception e) {
                    // Ignore individual failures
                }
            }

            executor.shutdown();
            try {
                if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
            }

            System.out.println("   - Hoàn thành scan. Tìm thấy " + foundSubdomains.size() + " subdomain hợp lệ");

        } catch (Exception e) {
            System.err.println("Lỗi khi scan subdomain: " + e.getMessage());
            return "Lỗi khi scan subdomain: " + e.getMessage();
        }

        // Trả về kết quả
        if (foundSubdomains.isEmpty()) {
            return "Không tìm thấy subdomain nào cho " + domain;
        } else {
            return String.join("\n", foundSubdomains);
        }
    }

    private List<String> loadWordlist() throws Exception {
        List<String> wordlist = new ArrayList<>();

        URL url = new URL(WORDLIST_URL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(10000);

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) {
                    wordlist.add(line);
                }
            }
        }

        return wordlist;
    }

    private boolean isSubdomainValid(String subdomain) {
        try {
            // Thử resolve DNS
            InetAddress address = InetAddress.getByName(subdomain);
            return address != null;

        } catch (Exception e) {
            return false;
        }
    }
}

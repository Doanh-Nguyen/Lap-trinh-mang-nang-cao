package com.ltmnc.common;


import com.fasterxml.jackson.annotation.JsonProperty;

public class Message {
    @JsonProperty("rawMessage")
    private String rawMessage;

    @JsonProperty("signature")
    private String signature;

    @JsonProperty("encryptedMessage")
    private String encryptedMessage;

    @JsonProperty("encryptedAESKey")
    private String encryptedAESKey;

    @JsonProperty("iv")
    private String iv;

    @JsonProperty("publicKey")
    private String publicKey;

    @JsonProperty("response")
    private String response;

    @JsonProperty("scanResults")
    private String scanResults;

    public Message() {
    }

    public Message(String rawMessage) {
        this.rawMessage = rawMessage;
    }

    // Getters and Setters
    public String getRawMessage() {
        return rawMessage;
    }

    public void setRawMessage(String rawMessage) {
        this.rawMessage = rawMessage;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getEncryptedMessage() {
        return encryptedMessage;
    }

    public void setEncryptedMessage(String encryptedMessage) {
        this.encryptedMessage = encryptedMessage;
    }

    public String getEncryptedAESKey() {
        return encryptedAESKey;
    }

    public void setEncryptedAESKey(String encryptedAESKey) {
        this.encryptedAESKey = encryptedAESKey;
    }

    public String getIv() {
        return iv;
    }

    public void setIv(String iv) {
        this.iv = iv;
    }

    public String getPublicKey() {
        return publicKey;
    }

    public void setPublicKey(String publicKey) {
        this.publicKey = publicKey;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getScanResults() {
        return scanResults;
    }

    public void setScanResults(String scanResults) {
        this.scanResults = scanResults;
    }

    @Override
    public String toString() {
        return "Message{" +
                "rawMessage='" + rawMessage + '\'' +
                ", signature='" + signature + '\'' +
                ", encryptedMessage='" + encryptedMessage + '\'' +
                ", encryptedAESKey='" + encryptedAESKey + '\'' +
                ", iv='" + iv + '\'' +
                ", publicKey='" + publicKey + '\'' +
                ", response='" + response + '\'' +
                ", scanResults='" + scanResults + '\'' +
                '}';
    }
}

package com.ltmnc.common;

import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class CryptoUtils {

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    // Generate AES Key
    public static SecretKey generateAESKey() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(256);
        return keyGen.generateKey();
    }

    // Generate IV for AES
    public static byte[] generateIV() {
        SecureRandom random = new SecureRandom();
        byte[] iv = new byte[16];
        random.nextBytes(iv);
        return iv;
    }

    // AES CBC Encryption
    public static String encryptAES(String plainText, SecretKey key, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    // AES CBC Decryption
    public static String decryptAES(String encryptedText, SecretKey key, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec ivSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
        byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
        return new String(decryptedBytes, "UTF-8");
    }

    // RSA Encryption
    public static String encryptRSA(byte[] data, PublicKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] encryptedBytes = cipher.doFinal(data);
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    // RSA Decryption
    public static byte[] decryptRSA(String encryptedData, PrivateKey privateKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return cipher.doFinal(Base64.getDecoder().decode(encryptedData));
    }

    // SHA256 Hash
    public static byte[] sha256Hash(String data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return digest.digest(data.getBytes("UTF-8"));
    }

    // RSA Sign with SHA256
    public static String signWithRSA(String data, PrivateKey privateKey) throws Exception {
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        signature.update(data.getBytes("UTF-8"));
        byte[] signatureBytes = signature.sign();
        return Base64.getEncoder().encodeToString(signatureBytes);
    }

    // RSA Verify with SHA256
    public static boolean verifyWithRSA(String data, String signatureStr, PublicKey publicKey) throws Exception {
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initVerify(publicKey);
        signature.update(data.getBytes("UTF-8"));
        byte[] signatureBytes = Base64.getDecoder().decode(signatureStr);
        return signature.verify(signatureBytes);
    }

    // Load Private Key from PEM file - FIXED VERSION
    public static PrivateKey loadPrivateKey(String filename) throws Exception {
        // Thử load từ classpath trước
        InputStream inputStream = CryptoUtils.class.getClassLoader().getResourceAsStream(filename);

        // Nếu không tìm thấy trong classpath, thử load từ file system
        if (inputStream == null) {
            try {
                return loadPrivateKeyFromFile(filename);
            } catch (Exception e) {
                throw new IllegalArgumentException("Cannot find private key file: " + filename +
                        ". Tried both classpath and file system.", e);
            }
        }

        try (PEMParser pemParser = new PEMParser(new InputStreamReader(inputStream))) {
            Object object = pemParser.readObject();

            if (object == null) {
                throw new IllegalArgumentException("No valid key found in file: " + filename);
            }

            JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");

            if (object instanceof PEMKeyPair) {
                // RSA Key Pair
                return converter.getPrivateKey(((PEMKeyPair) object).getPrivateKeyInfo());
            } else if (object instanceof PrivateKeyInfo) {
                // PKCS#8 Private Key
                return converter.getPrivateKey((PrivateKeyInfo) object);
            } else {
                throw new IllegalArgumentException("Unsupported private key format. Found: " +
                        object.getClass().getSimpleName() + ". Expected PEMKeyPair or PrivateKeyInfo.");
            }
        } catch (Exception e) {
            if (e instanceof IllegalArgumentException) {
                throw e;
            }
            throw new IllegalArgumentException("Invalid private key format in file: " + filename, e);
        }
    }

    // Load Private Key from file system
    public static PrivateKey loadPrivateKeyFromFile(String filepath) throws Exception {
        try (PEMParser pemParser = new PEMParser(new FileReader(filepath))) {
            Object object = pemParser.readObject();

            if (object == null) {
                throw new IllegalArgumentException("No valid key found in file: " + filepath);
            }

            JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");

            if (object instanceof PEMKeyPair) {
                return converter.getPrivateKey(((PEMKeyPair) object).getPrivateKeyInfo());
            } else if (object instanceof PrivateKeyInfo) {
                return converter.getPrivateKey((PrivateKeyInfo) object);
            } else {
                throw new IllegalArgumentException("Unsupported private key format. Found: " +
                        object.getClass().getSimpleName());
            }
        }
    }

    // Load Private Key from String
    public static PrivateKey loadPrivateKeyFromString(String privateKeyStr) throws Exception {
        try (PEMParser pemParser = new PEMParser(new StringReader(privateKeyStr))) {
            Object object = pemParser.readObject();

            if (object == null) {
                throw new IllegalArgumentException("No valid key found in string");
            }

            JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");

            if (object instanceof PEMKeyPair) {
                return converter.getPrivateKey(((PEMKeyPair) object).getPrivateKeyInfo());
            } else if (object instanceof PrivateKeyInfo) {
                return converter.getPrivateKey((PrivateKeyInfo) object);
            } else {
                throw new IllegalArgumentException("Unsupported private key format");
            }
        }
    }

    // Load Public Key from PEM file
    public static PublicKey loadPublicKey(String filename) throws Exception {
        InputStream inputStream = CryptoUtils.class.getClassLoader().getResourceAsStream(filename);

        if (inputStream == null) {
            throw new IllegalArgumentException("Cannot find public key file: " + filename);
        }

        try (PemReader pemReader = new PemReader(new InputStreamReader(inputStream))) {
            PemObject pemObject = pemReader.readPemObject();

            if (pemObject == null) {
                throw new IllegalArgumentException("No valid key found in file: " + filename);
            }

            byte[] keyBytes = pemObject.getContent();
            X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            return keyFactory.generatePublic(spec);
        }
    }

    // Load Public Key from String
    public static PublicKey loadPublicKeyFromString(String publicKeyStr) throws Exception {
        String cleanKey = publicKeyStr
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replace("-----END PUBLIC KEY-----", "")
                .replaceAll("\\s", "");

        byte[] keyBytes = Base64.getDecoder().decode(cleanKey);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePublic(spec);
    }

    // Convert Public Key to String
    public static String publicKeyToString(PublicKey publicKey) {
        byte[] keyBytes = publicKey.getEncoded();
        String base64Key = Base64.getEncoder().encodeToString(keyBytes);
        return "-----BEGIN PUBLIC KEY-----\n" + base64Key + "\n-----END PUBLIC KEY-----";
    }

    // Convert SecretKey to bytes
    public static byte[] secretKeyToBytes(SecretKey secretKey) {
        return secretKey.getEncoded();
    }

    // Convert bytes to SecretKey
    public static SecretKey bytesToSecretKey(byte[] keyBytes) {
        return new SecretKeySpec(keyBytes, "AES");
    }
}
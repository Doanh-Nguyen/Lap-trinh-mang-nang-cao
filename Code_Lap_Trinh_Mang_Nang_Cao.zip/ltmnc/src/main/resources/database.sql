-- LTMNC Database Schema
-- MySQL Database schema for storing session keys and information

CREATE TABLE IF NOT EXISTS session_keys (
                                            id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                            encrypted_aes_key TEXT NOT NULL,
                                            iv VARCHAR(255) NOT NULL,
    client_public_key TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    session_id VARCHAR(255) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for better performance
CREATE INDEX idx_session_keys_created_at ON session_keys(created_at);
CREATE INDEX idx_session_keys_session_id ON session_keys(session_id);

-- Insert some sample data for testing (optional)
-- INSERT INTO session_keys (encrypted_aes_key, iv, client_public_key, session_id)
-- VALUES ('sample_encrypted_key', 'sample_iv', 'sample_public_key', 'TEST_SESSION_001');

-- View to check latest sessions
CREATE VIEW latest_sessions AS
SELECT
    id,
    session_id,
    created_at,
    CHAR_LENGTH(encrypted_aes_key) as key_length,
    CHAR_LENGTH(client_public_key) as pubkey_length
FROM session_keys
ORDER BY created_at DESC;